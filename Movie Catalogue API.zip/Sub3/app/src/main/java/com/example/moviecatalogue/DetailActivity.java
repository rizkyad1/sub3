package com.example.moviecatalogue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.moviecatalogue.adapter.MovieAdapter;
import com.example.moviecatalogue.model.Pilem;
import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    TextView judul_dtl, rating_dtl, sinopsis_dtl, tahun_dtl;
    ImageView poster_dtl;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        progressBar = findViewById(R.id.progressBar);

        judul_dtl = findViewById(R.id.judul_Detail);
        rating_dtl = findViewById(R.id.rating_detail);
        poster_dtl = findViewById(R.id.poster_detail);
        sinopsis_dtl = findViewById(R.id.sinopsis_detail);
        tahun_dtl = findViewById(R.id.tahun_detail);

        tampilLoading(true);

        Intent intent = getIntent();
        Pilem pilem = intent.getParcelableExtra("DataMovieTV");

        tampilLoading(false);

        if (pilem.getJudul() != null) {
            judul_dtl.setText(pilem.getJudul());
        } else if (pilem.getJudul_tv() != null) {
            judul_dtl.setText(pilem.getJudul_tv());
        }

        rating_dtl.setText(pilem.getRating());
        Picasso.get().load(MovieAdapter.URL_GAMBAR + pilem.getPoster()).into(poster_dtl);
        sinopsis_dtl.setText(pilem.getSinopsis());

        if (pilem.getTahun() != null) {
            tahun_dtl.setText(pilem.getTahun());
        } else if (pilem.getTahun_tv() != null) {
            tahun_dtl.setText(pilem.getTahun_tv());
        }


    }

    private void tampilLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }
}
