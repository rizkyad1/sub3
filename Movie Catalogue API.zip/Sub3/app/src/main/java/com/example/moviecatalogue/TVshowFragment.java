package com.example.moviecatalogue;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.moviecatalogue.api.ApiClient;
import com.example.moviecatalogue.api.ApiInterface;
import com.example.moviecatalogue.adapter.TVshowAdapter;
import com.example.moviecatalogue.model.Pilem;
import com.example.moviecatalogue.viewModel.MainTvViewModel;

import java.util.ArrayList;

public class TVshowFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;

    FragmentActivity listener;

    TVshowAdapter tVshowAdapter;

    ApiInterface mApiInterface;
    private MainTvViewModel mainTvViewModel;

    public Observer<ArrayList<Pilem>> getTipi = new Observer<ArrayList<Pilem>>() {
        @Override
        public void onChanged(final ArrayList<Pilem> pilems) {
            if (pilems != null) {
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                tVshowAdapter = new TVshowAdapter(pilems, getContext());
                tVshowAdapter.setListTVshow(pilems);

                recyclerView.setAdapter(tVshowAdapter);
                tVshowAdapter.notifyDataSetChanged();

                tampilLoading(false);

                tVshowAdapter.setOnItemClickListener(new TVshowAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(int position) {
                        Intent intent = new Intent(listener, DetailActivity.class);
                        Pilem pilem = pilems.get(position);

                        intent.putExtra("DataMovieTV", pilem);
                        startActivity(intent);
                    }
                });
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tvshow, container, false);

        recyclerView = view.findViewById(R.id.tvshow_recycler);
        recyclerView.setHasFixedSize(true);
        progressBar = view.findViewById(R.id.progressBar);

        mApiInterface = ApiClient.getClient().create(ApiInterface.class);

        mainTvViewModel = new ViewModelProvider(listener).get(MainTvViewModel.class);
        mainTvViewModel.setListPilem();

        tampilLoading(true);
        tampilData();

        return view;
    }

    private void tampilLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    private void tampilData() {
        mainTvViewModel.getPilem().observe(listener, getTipi);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.listener = (FragmentActivity) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

//    @Override
//    public void onItemClick(int position) {
//        Intent intent = new Intent(listener, DetailActivity.class);
//        Pilem tv = daftarTvshow.get(position);
//
//        intent.putExtra("DataMovieTV", tv);
//        startActivity(intent);
//    }
}
