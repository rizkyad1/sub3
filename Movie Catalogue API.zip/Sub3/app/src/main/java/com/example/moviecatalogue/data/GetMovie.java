package com.example.moviecatalogue.data;

import com.example.moviecatalogue.model.Pilem;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetMovie {

    @SerializedName("results")
    List<Pilem> dataFilm;

    public List<Pilem> getDataFilm() {
        return dataFilm;
    }

}
