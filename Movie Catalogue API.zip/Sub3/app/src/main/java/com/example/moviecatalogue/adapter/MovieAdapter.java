package com.example.moviecatalogue.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moviecatalogue.model.Pilem;
import com.example.moviecatalogue.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {

    private ArrayList<Pilem> daftarPilem;
    private Context context;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public MovieAdapter(ArrayList<Pilem> daftarPilem, Context context) {
        this.daftarPilem = daftarPilem;
        this.context = context;
    }

    public void setListMovie(ArrayList<Pilem> daftarPilem) {
        this.daftarPilem = daftarPilem;
    }

    public static final String URL_GAMBAR = "https://image.tmdb.org/t/p/w185";

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.konten_film, parent, false);
        return new ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final Pilem film = daftarPilem.get(position);

        holder.judul_mv.setText(film.getJudul());
        holder.rating_mv.setText(film.getRating());
        holder.tahun_mv.setText(film.getTahun().substring(0, 4));
        Picasso.get().load(URL_GAMBAR + film.getPoster()).into(holder.poster_mv);
    }

    @Override
    public int getItemCount() {
        return daftarPilem.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView judul_mv, tahun_mv, rating_mv;
        ImageView poster_mv;
        RecyclerView recyclerView;

        public ViewHolder(@NonNull final View item) {
            super(item);

            recyclerView = item.findViewById(R.id.movie_recycler);
            judul_mv = item.findViewById(R.id.judul);
            rating_mv = item.findViewById(R.id.rating);
            tahun_mv = item.findViewById(R.id.tahun);
            poster_mv = item.findViewById(R.id.poster);

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
