package com.example.moviecatalogue.api;

import com.example.moviecatalogue.data.GetMovie;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("discover/movie")
    Call<GetMovie> getFilm (@Query("api_key") String apiKey, @Query("sort_by") String sort);

    @GET("discover/tv")
    Call<GetMovie> getTipi (@Query("api_key") String apiKey, @Query("sort_by") String sort);
}
