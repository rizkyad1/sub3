package com.example.moviecatalogue;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.moviecatalogue.api.ApiClient;
import com.example.moviecatalogue.api.ApiInterface;
import com.example.moviecatalogue.adapter.MovieAdapter;
import com.example.moviecatalogue.model.Pilem;
import com.example.moviecatalogue.viewModel.MainViewModel;

import java.util.ArrayList;

public class MovieFragment extends Fragment {

    private RecyclerView recylerview;
    private ProgressBar progressBar;

    FragmentActivity listener;

    MovieAdapter movieAdapter;

    ApiInterface mApiInterface;
    private MainViewModel mainViewModel;

    public Observer<ArrayList<Pilem>> getFilm = new Observer<ArrayList<Pilem>>() {
        @Override
        public void onChanged(final ArrayList<Pilem> pilems) {
            if (pilems != null) {
                recylerview.setLayoutManager(new LinearLayoutManager(getContext()));
                movieAdapter = new MovieAdapter(pilems, getContext());
                movieAdapter.setListMovie(pilems);

                recylerview.setAdapter(movieAdapter);
                movieAdapter.notifyDataSetChanged();

                tampilLoading(false);

                movieAdapter.setOnItemClickListener(new MovieAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(int position) {
                        Intent intent = new Intent(listener, DetailActivity.class);
                        Pilem pilem = pilems.get(position);

                        intent.putExtra("DataMovieTV", pilem);
                        startActivity(intent);
                    }
                });
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie, container, false);

        recylerview = view.findViewById(R.id.movie_recycler);
        recylerview.setHasFixedSize(true);

        progressBar = view.findViewById(R.id.progressBar);

        mApiInterface = ApiClient.getClient().create(ApiInterface.class);

        mainViewModel = new ViewModelProvider(listener).get(MainViewModel.class);
        mainViewModel.setListPilem();

        tampilLoading(true);
        tampilData();

        return view;
    }

    private void tampilLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    private void tampilData() {
        mainViewModel.getPilem().observe(listener, getFilm);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.listener = (FragmentActivity) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
