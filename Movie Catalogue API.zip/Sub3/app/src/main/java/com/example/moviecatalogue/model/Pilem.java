package com.example.moviecatalogue.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class Pilem implements Parcelable {

    @SerializedName("title")
    private String judul;

    @SerializedName("name")
    private String judul_tv;

    @SerializedName("vote_average")
    private String rating;

    @SerializedName("poster_path")
    private String poster;

    @SerializedName("overview")
    private String sinopsis;

    @SerializedName("release_date")
    private String tahun;

    @SerializedName("first_air_date")
    private String tahun_tv;

    public Pilem() {
    }

    protected Pilem(Parcel in) {
        judul = in.readString();
        rating = in.readString();
        poster = in.readString();
        sinopsis = in.readString();
        tahun = in.readString();
        judul_tv = in.readString();
        tahun_tv = in.readString();
    }


    public static final Creator<Pilem> CREATOR = new Creator<Pilem>() {
        @Override
        public Pilem createFromParcel(Parcel in) {
            return new Pilem(in);
        }

        @Override
        public Pilem[] newArray(int size) {
            return new Pilem[size];
        }
    };

    public String getTahun_tv() {
        return tahun_tv;
    }

    public void setTahun_tv(String tahun_tv) {
        this.tahun_tv = tahun_tv;
    }

    public String getJudul_tv() {
        return judul_tv;
    }

    public void setJudul_tv(String judul_tv) {
        this.judul_tv = judul_tv;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        this.tahun = tahun;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }


    public static Creator<Pilem> getCREATOR() {
        return CREATOR;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(judul);
        dest.writeString(rating);
        dest.writeString(poster);
        dest.writeString(sinopsis);
        dest.writeString(tahun);
        dest.writeString(judul_tv);
        dest.writeString(tahun_tv);
    }
}
