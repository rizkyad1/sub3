package com.example.moviecatalogue.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moviecatalogue.R;
import com.example.moviecatalogue.model.Pilem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TVshowAdapter extends RecyclerView.Adapter<TVshowAdapter.ViewHolder> {

    private ArrayList<Pilem> daftarTvshow;
    private Context context;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public TVshowAdapter(ArrayList<Pilem> daftarTvshow, Context context) {
        this.daftarTvshow = daftarTvshow;
        this.context = context;
    }

    public void setListTVshow(ArrayList<Pilem> daftarTvshow) {
        this.daftarTvshow = daftarTvshow;
    }

    public static final String URL_GAMBAR = "https://image.tmdb.org/t/p/w185";

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.konten_film, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Pilem tv = daftarTvshow.get(position);

        holder.judul_mv.setText(tv.getJudul_tv());
        holder.rating_mv.setText(tv.getRating());
        holder.tahun_mv.setText(tv.getTahun_tv().substring(0, 4));
        Picasso.get().load(URL_GAMBAR + tv.getPoster()).into(holder.poster_mv);
    }

    @Override
    public int getItemCount() {
        return daftarTvshow.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView judul_mv, tahun_mv, rating_mv;
        ImageView poster_mv;
        RecyclerView recyclerView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            recyclerView = itemView.findViewById(R.id.movie_recycler);
            judul_mv = itemView.findViewById(R.id.judul);
            rating_mv = itemView.findViewById(R.id.rating);
            tahun_mv = itemView.findViewById(R.id.tahun);
            poster_mv = itemView.findViewById(R.id.poster);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
}
