package com.example.moviecatalogue.viewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.moviecatalogue.api.ApiClient;
import com.example.moviecatalogue.api.ApiInterface;
import com.example.moviecatalogue.data.GetMovie;
import com.example.moviecatalogue.model.Pilem;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainViewModel extends ViewModel {

    private static final String API_KEY = "3016a153022698bfc7bf7069b67fd4a5";

    private MutableLiveData<ArrayList<Pilem>> listPilem = new MutableLiveData<>();

    public LiveData<ArrayList<Pilem>> getPilem(){
        return listPilem;
    }

    public void setListPilem() {
        ApiInterface mApiInterface;
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);

        Call<GetMovie> panggilFilm = mApiInterface.getFilm(API_KEY,"popularity.desc");
        panggilFilm.enqueue(new Callback<GetMovie>() {
            @Override
            public void onResponse(Call<GetMovie> call, Response<GetMovie> response) {
                List<Pilem> daftarFilm = response.body().getDataFilm();

                ArrayList<Pilem> arrayPilem = new ArrayList<>();
                arrayPilem.addAll(daftarFilm);

                listPilem.postValue(arrayPilem);
            }

            @Override
            public void onFailure(Call<GetMovie> call, Throwable t) {

            }
        });
    }

}
